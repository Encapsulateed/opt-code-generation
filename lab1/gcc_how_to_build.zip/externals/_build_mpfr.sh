#!/bin/bash -x

. ../_common.sh

CURRENT_DIR=`pwd`
NAME="mpfr-3.1.3"

# Build mpfr-3.1.0
mkdir -p ./${NAME}-build
cd ./${NAME}-build
make clean
make distclean
../${NAME}/configure --prefix=${CURRENT_DIR}/mpfr_install --with-gmp=${CURRENT_DIR}/gmp_install && make $JOBS && make install && echo "MPFR success!"

