#!/bin/bash -x

./_build_gmp.sh
./_build_ppl.sh
./_build_mpfr.sh
./_build_mpc.sh
./_build_cloog.sh



