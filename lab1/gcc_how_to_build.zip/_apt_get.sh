#!/bin/bash


sudo apt-get install gcc
sudo apt-get install g++
sudo apt-get install m4
sudo apt-get install libc6-dev
sudo apt-get install libc6-dev-i386

