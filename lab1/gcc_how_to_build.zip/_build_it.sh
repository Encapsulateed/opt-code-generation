#!/bin/bash

. ./_common.sh

CURR=`pwd`

export LD_LIBRARY_PATH="${CURR}/externals/mpc_install/lib:${LD_LIBRARY_PATH}"
export LD_LIBRARY_PATH="/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH}"


mkdir -p ./build
mkdir -p ./install

cd ./build
${CURR}/gcc-4.9.0/configure \
			    --prefix=${CURR}/install \
			    --enable-bootstrap \
			    --enable-languages=c \
			    --disable-libgomp \
			    --disable-graphit \
			    --with-ppl=${CURR}/externals/ppl_install \
			    --with-gmp=${CURR}/externals/gmp_install \
			    --with-mpfr=${CURR}/externals/mpfr_install \
			    --with-mpc=${CURR}/externals/mpc_install \
			    --disable-multilib


make ${JOBS}
make install

