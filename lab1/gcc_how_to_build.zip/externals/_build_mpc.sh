#!/bin/bash -x

. ../_common.sh

CURRENT_DIR=`pwd`
NAME="mpc-0.9"

# Build mpc-0.9
mkdir -p ./${NAME}-build
cd ./${NAME}-build
make clean
make distclean
../${NAME}/configure						\
    --with-mpfr-include=${CURRENT_DIR}/mpfr_install/include	\
    --with-mpfr-lib=${CURRENT_DIR}/mpfr_install/lib		\
    --with-gmp-include=${CURRENT_DIR}/gmp_install/include	\
    --with-gmp-lib=${CURRENT_DIR}/gmp_install/lib		\
    --prefix=${CURRENT_DIR}/mpc_install && make $JOBS && make install && echo "MPC success!"

