#!/bin/bash -x

. ../_common.sh

CURRENT_DIR=`pwd`
NAME="ppl-0.11.2"

# Build ppl-0.11.2
mkdir -p ./${NAME}-build
cd ./${NAME}-build
make clean
make distclean
../${NAME}/configure --prefix=${CURRENT_DIR}/ppl_install --with-gmp-prefix=${CURRENT_DIR}/gmp_install && make $JOBS && make install && echo "PPL success!"



