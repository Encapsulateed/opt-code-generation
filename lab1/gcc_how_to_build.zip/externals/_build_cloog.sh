#!/bin/bash -x

. ../_common.sh

CURRENT_DIR=`pwd`
NAME="cloog-parma-0.16.0"

# Build cloog-ppl-0.15.11
mkdir -p ./${NAME}-build
cd ./${NAME}-build
make clean
make distclean
#../${NAME}/configure --prefix=${CURRENT_DIR}/cloog_install \
#	--with-ppl=${CURRENT_DIR}/ppl_install \
#	--with-gmp=${CURRENT_DIR}/gmp_install \
#		&& make $JOBS && make install && echo "CLOOG success!"

../${NAME}/configure --prefix=${CURRENT_DIR}/cloog_install \
	--with-ppl-prefix=${CURRENT_DIR}/ppl_install \
	--with-gmp-prefix=${CURRENT_DIR}/gmp_install \
		&& make $JOBS && make install && echo "CLOOG success!"


