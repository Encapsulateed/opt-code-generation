#!/bin/bash -x

. ../_common.sh

CURRENT_DIR=`pwd`
NAME="gmp-5.0.2"

# Build gmp-5.0.2
mkdir -p ./${NAME}-build
cd ./${NAME}-build
make clean
make distclean
../${NAME}/configure --prefix=${CURRENT_DIR}/gmp_install --enable-cxx && make $JOBS && make install && echo "GMP success!"


